Project of Software Engineering. 
Written in Python Flask for backend, Ajax for connection between backend and frontend. Mysql for DB. HTML/CSS/JavaScript for frontend.
This project is developed by Yifeng Guo, Fengru Li, Dawei Wang, Yunfan Xu, Rui Wang and Nick.
